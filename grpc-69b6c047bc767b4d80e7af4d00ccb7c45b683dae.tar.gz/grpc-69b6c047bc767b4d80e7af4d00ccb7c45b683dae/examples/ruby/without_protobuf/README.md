gRPC (Ruby) without protobuf
========================

This directory contains a simple example of using gRPC without protobuf.

This is mainly intended to show basic usage of the GRPC::GenericService module
